// ============================================================
// CONSTANTS
// ============================================================

const FT_PER_NM = 6076.12;
const M_PER_NM = 1852;
const DEG_PER_M_LAT = 1 / 111320; // approx. meters per degree latitude

let bandIdCounter = 0;


// ============================================================
// LEAFLET MAP SETUP
// ============================================================

const map = L.map("map", { zoomControl: true });

let onlineTileLayer = null;
let localImageOverlay = null;

const planeDivIcon = L.divIcon({
    className: "",
    html:
        '<div class="plane-icon" id="planeIconInner">' +
        '<svg width="26" height="26" viewBox="0 0 24 24">' +
        '<path d="M12 2 L15 10 L22 13 L15 14.5 L14 21 L12 18.5 L10 21 L9 14.5 L2 13 L9 10 Z" ' +
        'fill="#2563eb" stroke="#1d4ed8" stroke-width="0.5"/>' +
        "</svg></div>",
    iconSize: [26, 26],
    iconAnchor: [13, 13]
});

const acftMarker = L.marker([0, 0], { icon: planeDivIcon, draggable: true }).addTo(map);

const circle = L.circle([0, 0], {
    radius: 1,
    color: "#2563eb",
    weight: 2,
    fillColor: "#2563eb",
    fillOpacity: 0.12
}).addTo(map);

const centerMarker = L.circleMarker([0, 0], {
    radius: 4,
    color: "#991b1b",
    weight: 2,
    fillColor: "#991b1b",
    fillOpacity: 1
}).addTo(map);

const driftLine = L.polyline([[0, 0], [0, 0]], {
    color: "#991b1b",
    weight: 1.5,
    dashArray: "4 4"
}).addTo(map);


function applyMapSource() {

    const source = document.getElementById("mapSource").value;
    const localGroup = document.getElementById("localMapGroup");

    if (source === "online") {

        localGroup.style.display = "none";

        if (localImageOverlay) {
            map.removeLayer(localImageOverlay);
            localImageOverlay = null;
        }

        if (!onlineTileLayer) {
            onlineTileLayer = L.tileLayer(
                "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
                {
                    maxZoom: 19,
                    attribution: "&copy; OpenStreetMap contributors"
                }
            );
        }

        onlineTileLayer.addTo(map);

    } else {

        localGroup.style.display = "block";

        if (onlineTileLayer) {
            map.removeLayer(onlineTileLayer);
        }

        const imageUrl = document.getElementById("localImageUrl").value.trim();
        const nwLat = Number(document.getElementById("nwLat").value);
        const nwLon = Number(document.getElementById("nwLon").value);
        const seLat = Number(document.getElementById("seLat").value);
        const seLon = Number(document.getElementById("seLon").value);

        if (
            !imageUrl ||
            !Number.isFinite(nwLat) || !Number.isFinite(nwLon) ||
            !Number.isFinite(seLat) || !Number.isFinite(seLon)
        ) {
            return;
        }

        const bounds = L.latLngBounds([nwLat, nwLon], [seLat, seLon]);

        if (localImageOverlay) {
            map.removeLayer(localImageOverlay);
        }

        localImageOverlay = L.imageOverlay(imageUrl, bounds).addTo(map);
        map.fitBounds(bounds);
    }
}


// ============================================================
// İRTİFA KADEMELERİ TABLOSU (dinamik satırlar)
// ============================================================

function addBandRow(topAltFt, speedKt, windDirDeg, windSpdKt) {

    bandIdCounter++;
    const rowId = "band-" + bandIdCounter;

    const row = document.createElement("div");
    row.className = "band-row";
    row.id = rowId;

    row.innerHTML =
        '<input type="number" class="band-alt" step="100" value="' + topAltFt + '">' +
        '<input type="number" class="band-speed" step="1" value="' + speedKt + '">' +
        '<input type="number" class="band-wdir" step="1" min="0" max="359" value="' + windDirDeg + '">' +
        '<input type="number" class="band-wspd" step="1" value="' + windSpdKt + '">' +
        '<button type="button" class="remove-row-btn" title="Kaldır">&times;</button>';

    row.querySelector(".remove-row-btn").addEventListener("click", function () {
        row.remove();
        recalc();
    });

    document.getElementById("bandsContainer").appendChild(row);
}


function readBands() {

    const rows = document.querySelectorAll("#bandsContainer .band-row");
    const bands = [];

    rows.forEach(function (row) {
        bands.push({
            topAltFt: Number(row.querySelector(".band-alt").value),
            speedKt: Number(row.querySelector(".band-speed").value),
            windDirDeg: Number(row.querySelector(".band-wdir").value),
            windSpdKt: Number(row.querySelector(".band-wspd").value)
        });
    });

    bands.sort(function (a, b) {
        return a.topAltFt - b.topAltFt;
    });

    return bands;
}


// ============================================================
// SÜZÜLME KONİSİ HESABI
// ============================================================

function computeGlideCircle(acftAltFt, glideRatio, bands) {

    if (bands.length === 0) {
        return { error: "En az bir irtifa kademesi tanımlayın." };
    }

    for (const b of bands) {
        if (
            !Number.isFinite(b.topAltFt) || !Number.isFinite(b.speedKt) ||
            !Number.isFinite(b.windDirDeg) || !Number.isFinite(b.windSpdKt) ||
            b.speedKt <= 0
        ) {
            return { error: "Kademe tablosundaki değerleri kontrol edin (sürat > 0 olmalı)." };
        }
    }

    let bottom = 0;
    let totalDistNm = 0;
    let totalTimeHr = 0;
    let dxNm = 0; // doğu yönü (+)
    let dyNm = 0; // kuzey yönü (+)

    for (const b of bands) {

        if (bottom >= acftAltFt) break;

        const top = Math.min(b.topAltFt, acftAltFt);
        const thicknessFt = top - bottom;

        if (thicknessFt <= 0) {
            bottom = top;
            continue;
        }

        const distNm = (thicknessFt / FT_PER_NM) * glideRatio;
        const timeHr = distNm / b.speedKt;
        const driftNm = b.windSpdKt * timeHr;

        // Meteorolojik rüzgar yönü "nereden estiği"dir; sürüklenme rüzgarın
        // "gittiği" yöne doğrudur.
        const toDirRad = (((b.windDirDeg + 180) % 360) * Math.PI) / 180;

        dxNm += driftNm * Math.sin(toDirRad);
        dyNm += driftNm * Math.cos(toDirRad);

        totalDistNm += distNm;
        totalTimeHr += timeHr;

        bottom = top;
    }

    // Uçağın irtifası, tanımlı kademelerin en üstünü aşıyorsa son kademenin
    // değerleriyle tamamla.
    if (bottom < acftAltFt) {

        const last = bands[bands.length - 1];
        const thicknessFt = acftAltFt - bottom;

        const distNm = (thicknessFt / FT_PER_NM) * glideRatio;
        const timeHr = distNm / last.speedKt;
        const driftNm = last.windSpdKt * timeHr;

        const toDirRad = (((last.windDirDeg + 180) % 360) * Math.PI) / 180;

        dxNm += driftNm * Math.sin(toDirRad);
        dyNm += driftNm * Math.cos(toDirRad);

        totalDistNm += distNm;
        totalTimeHr += timeHr;
    }

    return {
        radiusNm: totalDistNm,
        driftNm: Math.hypot(dxNm, dyNm),
        driftBearingDeg: (Math.atan2(dxNm, dyNm) * 180 / Math.PI + 360) % 360,
        timeHr: totalTimeHr,
        dxNm: dxNm,
        dyNm: dyNm
    };
}


// ============================================================
// ANA GÜNCELLEME FONKSİYONU
// ============================================================

function recalc() {

    const error = document.getElementById("error");
    error.style.display = "none";

    const lat = Number(document.getElementById("lat").value);
    const lon = Number(document.getElementById("lon").value);
    const altitude = Number(document.getElementById("altitude").value);
    const heading = Number(document.getElementById("heading").value);
    const glideRatio = Number(document.getElementById("glideRatio").value);

    if (!Number.isFinite(lat) || lat < -90 || lat > 90) {
        showError("Geçerli bir enlem girin (-90 ile 90 arası).");
        return;
    }

    if (!Number.isFinite(lon) || lon < -180 || lon > 180) {
        showError("Geçerli bir boylam girin (-180 ile 180 arası).");
        return;
    }

    if (!Number.isFinite(altitude) || altitude <= 0) {
        showError("Geçerli bir irtifa girin (0'dan büyük).");
        return;
    }

    if (!Number.isFinite(heading)) {
        showError("Geçerli bir baş istikameti girin.");
        return;
    }

    if (!Number.isFinite(glideRatio) || glideRatio <= 0) {
        showError("Geçerli bir süzülme oranı girin (0'dan büyük).");
        return;
    }

    const bands = readBands();
    const result = computeGlideCircle(altitude, glideRatio, bands);

    if (result.error) {
        showError(result.error);
        return;
    }

    // --------------------------------------------------------
    // Uçak işaretçisi
    // --------------------------------------------------------

    acftMarker.setLatLng([lat, lon]);

    const planeInner = document.getElementById("planeIconInner");
    if (planeInner) {
        planeInner.style.transform = "rotate(" + heading + "deg)";
    }

    // --------------------------------------------------------
    // Çember merkezini rüzgara göre kaydır
    // --------------------------------------------------------

    const dxM = result.dxNm * M_PER_NM;
    const dyM = result.dyNm * M_PER_NM;

    const latOffsetDeg = dyM * DEG_PER_M_LAT;
    const lonOffsetDeg = dxM / (111320 * Math.cos((lat * Math.PI) / 180));

    const centerLat = lat + latOffsetDeg;
    const centerLon = lon + lonOffsetDeg;

    const radiusM = result.radiusNm * M_PER_NM;

    circle.setLatLng([centerLat, centerLon]);
    circle.setRadius(radiusM);

    centerMarker.setLatLng([centerLat, centerLon]);
    driftLine.setLatLngs([[lat, lon], [centerLat, centerLon]]);

    // --------------------------------------------------------
    // Sonuç metinleri
    // --------------------------------------------------------

    document.getElementById("radiusOut").textContent =
        result.radiusNm.toFixed(2) + " NM (" + (result.radiusNm * 1.852).toFixed(2) + " km)";

    document.getElementById("driftOut").textContent =
        result.driftNm.toFixed(2) + " NM, " + result.driftBearingDeg.toFixed(0) + "°'ye doğru";

    document.getElementById("timeOut").textContent =
        (result.timeHr * 60).toFixed(1) + " dk";

    document.getElementById("acftCoordOut").textContent =
        lat.toFixed(5) + ", " + lon.toFixed(5);

    document.getElementById("centerCoordOut").textContent =
        centerLat.toFixed(5) + ", " + centerLon.toFixed(5);
}


function showError(message) {
    const error = document.getElementById("error");
    error.textContent = message;
    error.style.display = "block";
}


// ============================================================
// KONUM SENKRONİZASYONU (harita <-> kutucuklar)
// ============================================================

map.on("click", function (e) {
    document.getElementById("lat").value = e.latlng.lat.toFixed(5);
    document.getElementById("lon").value = e.latlng.lng.toFixed(5);
    recalc();
});

acftMarker.on("dragend", function () {
    const p = acftMarker.getLatLng();
    document.getElementById("lat").value = p.lat.toFixed(5);
    document.getElementById("lon").value = p.lng.toFixed(5);
    recalc();
});


// ============================================================
// OLAY DİNLEYİCİLERİ
// ============================================================

document.getElementById("mapSource").addEventListener("change", function () {
    applyMapSource();
    recalc();
});

["localImageUrl", "nwLat", "nwLon", "seLat", "seLon"].forEach(function (id) {
    document.getElementById(id).addEventListener("input", function () {
        applyMapSource();
    });
});

["lat", "lon", "altitude", "heading", "glideRatio"].forEach(function (id) {
    document.getElementById(id).addEventListener("input", recalc);
});

document.getElementById("bandsContainer").addEventListener("input", recalc);

document.getElementById("addBandBtn").addEventListener("click", function () {
    addBandRow(10000, 80, 270, 10);
    recalc();
});


// ============================================================
// BAŞLANGIÇ DURUMU
// ============================================================

addBandRow(3000, 70, 270, 10);
addBandRow(8000, 90, 280, 25);

applyMapSource();

const initLat = Number(document.getElementById("lat").value);
const initLon = Number(document.getElementById("lon").value);
map.setView([initLat, initLon], 9);

recalc();
